It is recommended to compile the run.c file using mingw C Compiler in windows.

Mingw C compiler is available with Dev C++ and Code Blocks IDE try them out!

To build and run the program by directly downloading from github refer [ Instructions](/Source%20Code/C%20Source%20code/Install.md) here.

